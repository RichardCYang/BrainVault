from pathlib import Path
import subprocess, os, sys, time, json
root='/mnt/data/brainvault_workspace'
audit=Path('/mnt/data/brainvault_audit')
name=sys.argv[1]; args=sys.argv[2:]
env=os.environ.copy(); env.update(GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0',GIT_PAGER='cat',HOME='/home/oai',npm_config_cache='/mnt/data/brainvault_audit/npm-cache')
if args[0]=='git':
    args=['git','--no-optional-locks','-c','safe.directory='+root,'-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null','-c','gc.auto=0']+args[1:]
t=time.monotonic()
with (audit/(name+'.log')).open('w') as f:
    f.write('$ '+' '.join(args)+'\n'); f.flush()
    p=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,user=1000,group=1000,extra_groups=[],check=False)
meta={'command':args,'exit_code':p.returncode,'seconds':round(time.monotonic()-t,3)}
(audit/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta)); print((audit/(name+'.log')).read_text(errors='replace')[-12000:])
sys.exit(p.returncode)
