from pathlib import Path, PurePosixPath
import zipfile, subprocess, os, json, stat
archive=Path('/mnt/data/BrainVault.zip')
root=Path('/mnt/data/brainvault_workspace'); root.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
    names=set()
    for info in z.infolist():
        p=PurePosixPath(info.filename)
        if p.is_absolute() or '..' in p.parts or '\\' in info.filename or info.filename in names:
            raise ValueError(f'Unsafe/duplicate path: {info.filename}')
        names.add(info.filename)
        if stat.S_ISLNK(info.external_attr >> 16):
            raise ValueError(f'Unexpected symlink: {info.filename}')
    z.extractall(root)
# Git is inspected only with read-only Git CLI operations. No index refresh,
# hooks, background maintenance, configuration writes, checkout, or commits.
env=os.environ.copy()
env.update(GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0', GIT_PAGER='cat')
commands=[['status','--short'],['log','-18','--date=iso-strict','--format=%h %ad %s'], ['log','-8','--stat','--oneline'],['ls-files']]
log=[]
for args in commands:
    cmd=['git','--no-optional-locks','-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null','-c','gc.auto=0']+args
    result=subprocess.run(cmd,cwd=root,env=env,text=True,capture_output=True,check=False)
    log.append('$ '+' '.join(cmd)+'\n'+result.stdout+result.stderr)
    print(log[-1] if args[0]!='ls-files' else '\n'.join(result.stdout.splitlines()[:100]))
Path('/mnt/data/brainvault_audit/initial_git_diagnostics.txt').write_text('\n'.join(log))
# Hash files through standard filesystem utilities, not Python object parsing.
result=subprocess.run(['bash','-c',"find .git -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum"],cwd=root,text=True,capture_output=True,check=True)
Path('/mnt/data/brainvault_audit/git_before.sha256').write_text(result.stdout)
