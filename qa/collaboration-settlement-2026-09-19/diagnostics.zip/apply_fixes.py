from pathlib import Path
p=Path('/mnt/data/brainvault_workspace/public/app.js')
raw=p.read_bytes(); newline=b'\r\n' if b'\r\n' in raw else b'\n'
s=raw.decode().replace('\r\n','\n')
def replace_once(old,new):
    global s
    if s.count(old)!=1: raise RuntimeError(f'Expected unique patch anchor ({s.count(old)} matches): {old[:90]}')
    s=s.replace(old,new,1)
replace_once('''    let block;
    try {
      block = await session.upsertBlock({
        ...current,
        ...payload,
        parentBlockId: normalizeParentBlockId(row.dataset.parentBlockId),
        sortOrder: Number(current.sortOrder ?? 0)
      });
    } catch (error) {''','''    let block;
    let mutation;
    try {
      mutation = session.upsertBlock({
        ...current,
        ...payload,
        parentBlockId: normalizeParentBlockId(row.dataset.parentBlockId),
        sortOrder: Number(current.sortOrder ?? 0)
      });
      // Direct saves and input-driven saves must share one completion owner.
      // A session/page fence alone cannot distinguish two edits in this session.
      collaborationBlockMutationPromises.set(blockId, mutation);
      syncBeforeUnloadProtection();
      block = await mutation;
    } catch (error) {''')
replace_once('''      if (!isCurrentCollaborationMutationContext(authenticationScope, pageId, session)) return null;
      rejectLocalBlockMutation(row, error);
      throw error;
    }
    // The old session may resolve after a same-page collaboration generation''','''      if (mutation && collaborationBlockMutationPromises.get(blockId) === mutation) {
        collaborationBlockMutationPromises.delete(blockId);
      } else if (mutation) {
        // Preserve failure propagation for the initiating caller, but never
        // restore the editor or clear tracking owned by a newer local edit.
        if (!isCurrentCollaborationMutationContext(authenticationScope, pageId, session)) return null;
        throw error;
      }
      if (!isCurrentCollaborationMutationContext(authenticationScope, pageId, session)) return null;
      const currentRow = findRenderedBlockRow(blockId);
      if (
        currentRow
        && currentRow.dataset.deleting !== "true"
        && getBlockById(blockId)
        && jsonValuesMatch(buildBlockPayload(currentRow), payload)
      ) rejectLocalBlockMutation(currentRow, error);
      syncBeforeUnloadProtection();
      throw error;
    }
    if (collaborationBlockMutationPromises.get(blockId) !== mutation) return null;
    collaborationBlockMutationPromises.delete(blockId);
    // The old session may resolve after a same-page collaboration generation''')
replace_once('''    if (!isCurrentCollaborationMutationContext(authenticationScope, pageId, session)) return null;
    recordBlockEditorHistory(row, payload, current);
    row.classList.remove("is-dirty", "is-saving", "save-error");''','''    if (!isCurrentCollaborationMutationContext(authenticationScope, pageId, session)) return null;
    const currentRow = findRenderedBlockRow(blockId);
    if (
      !currentRow
      || currentRow.dataset.deleting === "true"
      || !getBlockById(blockId)
      || !jsonValuesMatch(buildBlockPayload(currentRow), payload)
    ) {
      syncBeforeUnloadProtection();
      return null;
    }
    // An equivalent rebuild is still the same edit, but only its live row may
    // receive preview, history and saved-state changes after the await.
    row = currentRow;
    recordBlockEditorHistory(row, payload, current);
    row.classList.remove("is-dirty", "is-saving", "save-error");''')
replace_once('''    elements.pageTitle.value = title;
    try {
      await session.setTitle(title);
    } catch (error) {
      if (!isCurrentCollaborationMutationContext(authenticationScope, pageId, session)) return null;''','''    elements.pageTitle.value = title;
    let mutation;
    try {
      mutation = session.setTitle(title);
      // Use the same ownership slot as scheduled title edits. Matching text is
      // not enough: an A -> B -> A sequence still has a newer mutation owner.
      collaborationTitleMutationPromise = mutation;
      syncBeforeUnloadProtection();
      await mutation;
    } catch (error) {
      if (mutation && collaborationTitleMutationPromise === mutation) {
        collaborationTitleMutationPromise = null;
      } else if (mutation) {
        if (!isCurrentCollaborationMutationContext(authenticationScope, pageId, session)) return null;
        throw error;
      }
      if (!isCurrentCollaborationMutationContext(authenticationScope, pageId, session)) return null;
      // New input can be deliberately unscheduled (notably a blank title).
      // The failed request has no authority to restore over that input either.
      if (elements.pageTitle.value !== title) {
        syncBeforeUnloadProtection();
        throw error;
      }
      elements.pageTitle.classList.remove("is-saving");''')
replace_once('''      } else {
        elements.pageTitle.value = previousTitle;
      }
      setStatus(getRejectedLocalMutationMessage(error), true);
      throw error;
    }
    if (!isCurrentCollaborationMutationContext(authenticationScope, pageId, session)) return null;
    recordPageTitleEditorHistory(previousTitle);''','''      } else {
        elements.pageTitle.value = state.selectedPage?.title ?? previousTitle;
      }
      setStatus(getRejectedLocalMutationMessage(error), true);
      syncBeforeUnloadProtection();
      throw error;
    }
    if (collaborationTitleMutationPromise !== mutation) return null;
    collaborationTitleMutationPromise = null;
    if (!isCurrentCollaborationMutationContext(authenticationScope, pageId, session)) return null;
    if (elements.pageTitle.value !== title) {
      syncBeforeUnloadProtection();
      return null;
    }
    elements.pageTitle.classList.remove("is-saving", "save-error");
    recordPageTitleEditorHistory(previousTitle);''')
# Preserve the upload's line-ending convention. Only this source file is patched.
p.write_bytes(s.encode().replace(b'\n',newline))
