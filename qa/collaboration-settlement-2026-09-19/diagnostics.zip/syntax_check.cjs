const fs = require('node:fs');
const path = require('node:path');
const ts = require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');
const root = process.argv[2];
let files = 0; const errors = [];
function walk(dir) {
 for (const entry of fs.readdirSync(dir, {withFileTypes: true})) {
  if (['.git', 'node_modules', 'dist'].includes(entry.name)) continue;
  const p = path.join(dir, entry.name);
  if (entry.isDirectory()) walk(p);
  else if (/\.(?:[cm]?js|tsx?|jsx)$/.test(entry.name)) {
   const kind = /\.tsx$/.test(p) ? ts.ScriptKind.TSX : /\.jsx$/.test(p) ? ts.ScriptKind.JSX : /\.ts$/.test(p) ? ts.ScriptKind.TS : ts.ScriptKind.JS;
   const source = ts.createSourceFile(p, fs.readFileSync(p, 'utf8'), ts.ScriptTarget.Latest, true, kind);
   files++;
   for (const e of source.parseDiagnostics) errors.push({file: path.relative(root,p), message: ts.flattenDiagnosticMessageText(e.messageText,'\n'), start:e.start});
  }
 }
}
walk(root);
console.log(JSON.stringify({compiler:ts.version, scope:'Syntax parsing only; not dependency resolution, type checking, or a production build',files,errors},null,2));
process.exitCode = errors.length ? 1 : 0;
