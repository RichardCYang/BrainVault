from pathlib import Path
root=Path('/mnt/data/brainvault_workspace')
p=root/'tests/save-admission-revision-race.node.test.mjs'
s=p.read_bytes().decode().replace('\r\n','\n')
anchor='import { rebaseCommittedBlockContent, rebaseCommittedPageTitle } from "../public/save-rebase.js";\n'
assert s.count(anchor)==1
s=s.replace(anchor,anchor+'''
// Recovery persistence legitimately refreshes updatedAt. Keep time deterministic
// so byte-for-byte draft assertions do not depend on two writes sharing a real
// millisecond. Node's per-test mock is reset automatically after each case.
test.beforeEach((context) => {
  context.mock.timers.enable({ apis: ["Date"], now: 1_800_000_000_000 });
});
''')
p.write_bytes(s.encode().replace(b'\n',b'\r\n'))
p=root/'tests/authentication-credential-boundary.node.test.mjs'
s=p.read_bytes().decode().replace('\r\n','\n')
for old,new in [
 ('const awaitedBlockMutation = awaitedBlock.indexOf("block = await session.upsertBlock");','''const awaitedBlockMutation = awaitedBlock.indexOf("block = await mutation;");
  const blockOwnership = awaitedBlock.indexOf("collaborationBlockMutationPromises.set(blockId, mutation)");
  assert.ok(blockOwnership >= 0 && blockOwnership < awaitedBlockMutation,
    "direct block saves must register their completion owner before awaiting durability");'''),
 ('awaitedBlock.indexOf("rejectLocalBlockMutation(row, error)", awaitedBlockCatch)','awaitedBlock.indexOf("rejectLocalBlockMutation(currentRow, error)", awaitedBlockCatch)'),
 ('const awaitedTitleMutation = saveTitle.indexOf("await session.setTitle(title)");','''const awaitedTitleMutation = saveTitle.indexOf("await mutation;");
  const titleOwnership = saveTitle.indexOf("collaborationTitleMutationPromise = mutation");
  assert.ok(titleOwnership >= 0 && titleOwnership < awaitedTitleMutation,
    "direct title saves must register their completion owner before awaiting durability");''')]:
 assert s.count(old)==1,old
 s=s.replace(old,new,1)
p.write_bytes(s.encode().replace(b'\n',b'\r\n'))
