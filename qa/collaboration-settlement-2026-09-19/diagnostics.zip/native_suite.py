from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import subprocess,os,re,json,time,sys,signal
root=Path(sys.argv[1]);name=sys.argv[2]
audit=Path('/mnt/data/brainvault_audit')/name;audit.mkdir(exist_ok=True)
files=sorted((root/'tests').glob('*.node.test.mjs'))
if len(sys.argv)>3:
 names=set(json.loads(Path(sys.argv[3]).read_text()));files=[p for p in files if p.name in names]
env=os.environ.copy();env.update(GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0',HOME='/home/oai')
def run(path):
 cmd=['node','--experimental-strip-types','--test','--test-reporter=tap',str(path.relative_to(root))]
 start=time.monotonic();timeout=False
 with (audit/(path.stem+'.log')).open('w') as f:
  f.write('$ '+' '.join(cmd)+'\n');f.flush()
  proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,user=1000,group=1000,extra_groups=[],start_new_session=True)
  try:code=proc.wait(timeout=40)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGKILL);proc.wait();timeout=True;code=124;f.write('\nAUDIT: 40-second per-file timeout\n')
 text=(audit/(path.stem+'.log')).read_text(errors='replace')
 result={'file':path.name,'exit_code':code,'timeout':timeout,'seconds':round(time.monotonic()-start,3)}
 for key in ['tests','suites','pass','fail','cancelled','skipped','todo']:
  values=re.findall(r'^# '+key+r' (\d+)$',text,re.M);result[key]=int(values[-1]) if values else 0
 (audit/(path.stem+'.json')).write_text(json.dumps(result,indent=2)+'\n')
 return result
results=[];start=time.monotonic()
with ThreadPoolExecutor(max_workers=4) as pool:
 for future in as_completed([pool.submit(run,p) for p in files]):
  r=future.result();results.append(r)
  if r['exit_code'] or len(results)%50==0: print(len(results),'/',len(files),r['file'],'exit',r['exit_code'],flush=True)
results.sort(key=lambda r:r['file'])
summary={'files':len(results),'passing_files':sum(r['exit_code']==0 for r in results),'failing_files':sum(r['exit_code']!=0 for r in results),'seconds':round(time.monotonic()-start,3),'totals':{k:sum(r[k] for r in results) for k in ['tests','suites','pass','fail','cancelled','skipped','todo']},'results':results}
(audit/'summary.json').write_text(json.dumps(summary,indent=2))
(audit/'failed-files.json').write_text(json.dumps([r['file'] for r in results if r['exit_code']],indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='results'},indent=2),flush=True)
