const ts = require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js');
const fs = require('node:fs'); const path = require('node:path');
const root = '/mnt/data/brainvault_workspace';
const files = JSON.parse(fs.readFileSync('/mnt/data/maintenance_diagnostics/syntax-files.json','utf8'));
let errors=0;
for (const file of files) {
 const parsed = ts.createSourceFile(file,fs.readFileSync(path.join(root,file),'utf8'),ts.ScriptTarget.Latest,true);
 for (const d of parsed.parseDiagnostics) {
  errors++; const loc=parsed.getLineAndCharacterOfPosition(d.start??0);
  console.log(`${file}:${loc.line+1}:${loc.character+1}: ${ts.flattenDiagnosticMessageText(d.messageText,' ')}`);
 }
}
console.log(JSON.stringify({parser:'TypeScript '+ts.version,files:files.length,parseErrors:errors,semanticTypecheck:false}));
process.exitCode=errors?1:0;
