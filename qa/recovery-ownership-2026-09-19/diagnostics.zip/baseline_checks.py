from pathlib import Path
import subprocess, os, time, json
w=Path('/mnt/data/brainvault_workspace'); d=Path('/mnt/data/maintenance_diagnostics'); results=[]
checks=[('npm-ci',['npm','ci','--ignore-scripts','--no-audit','--no-fund','--fetch-retries=0','--fetch-timeout=10000']),('lockfile',['node','scripts/lockfile-registry.mjs']),('baseline-targeted',['node','--test','tests/save-admission-revision-race.node.test.mjs','tests/collaboration-direct-save-settlement.node.test.mjs','tests/direct-recovery-boundary.node.test.mjs','tests/direct-recovery-durability.node.test.mjs','tests/block-save-admission-fence.node.test.mjs','tests/page-title-save-admission-fence.node.test.mjs'])]
for label,cmd in checks:
 started=time.monotonic()
 with (d/(label+'.log')).open('w') as out:
  out.write('$ '+' '.join(cmd)+'\n');out.flush()
  try: p=subprocess.run(cmd,cwd=w,stdout=out,stderr=subprocess.STDOUT,timeout=35); code=p.returncode
  except subprocess.TimeoutExpired: code='timeout'
 results.append({'label':label,'command':cmd,'exit_code':code,'seconds':round(time.monotonic()-started,3)})
 print(label,code,flush=True)
(d/'baseline-checks.json').write_text(json.dumps(results,indent=2))
