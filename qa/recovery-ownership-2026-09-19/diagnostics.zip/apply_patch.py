from pathlib import Path
w=Path('/mnt/data/brainvault_workspace')
p=w/'public/app.js'
raw=p.read_bytes(); old=raw.decode('utf-8').replace('\r\n','\n')
start=old.index('function scheduleDirectTitleRecoveryAdmission(')
end=old.index('function persistPageTitleDraftValue(', start)
new=r'''function scheduleDirectTitleRecoveryAdmission(sequence, pageId) {
  const authenticationScope = captureAuthenticatedSessionScope();
  const navigationGeneration = workspaceNavigationGeneration;
  const input = elements.pageTitle;
  const editRevision = pageTitleEditRevision;
  const draftSourceId = pageTitleDraftSourceId || pageDraftSourceId;
  const value = input.value;
  // The title element and its sequence counter can be reused after navigation,
  // login, or workspace replacement. A sequence alone is not an edit identity.
  const isCurrentAdmission = () => Boolean(
    isCurrentAuthenticatedSessionScope(authenticationScope)
      && isCurrentWorkspaceNavigation(navigationGeneration)
      && state.selectedPage?.id === pageId
      && !isCollaborativePage()
      && elements.pageTitle === input
      && pageTitleEditRevision === editRevision
      && (pageTitleDraftSourceId || pageDraftSourceId) === draftSourceId
      && input.value === value
      && (Number.parseInt(input.dataset.recoveryAdmissionSequence ?? "0", 10) || 0) === sequence
  );
  if (!isCurrentAdmission()) return;
  void requireDirectRecoveryDurability("direct-title-visible-admission", null, { preserveInput: false })
    .then(() => {
      if (!isCurrentAdmission()) return;
      if (finishDirectRecoveryVisibilityAdmission(input, sequence)) {
        pageTitleLastDurableValue = value;
      }
    })
    .catch(async (error) => {
      // Refresh is asynchronous too. Recheck on both sides so a failure cannot
      // roll back input belonging to an editor that replaced this admission.
      if (!isCurrentAdmission()) return;
      try { await recoveryStorage.refresh?.(); } catch { /* the original durability error remains authoritative */ }
      if (!isCurrentAdmission()) return;
      const scope = getDraftScope(pageId);
      const durableDraft = scope
        ? pageDraftStore.loadPage(scope.userId, scope.pageId, draftSourceId)?.title
        : null;
      const fallback = durableDraft?.value ?? pageTitleLastDurableValue ?? state.selectedPage?.title ?? "";
      pageTitleEditRevision = durableDraft?.revision ?? pageTitleSavedRevision;
      pageTitleDraftExpectedVersion = durableDraft?.expectedVersion ?? getPositiveVersion(state.selectedPage?.version);
      updateInputValuePreservingSelection(input, fallback);
      applyPageSummaryUpdate(pageId, { title: fallback });
      finishDirectRecoveryVisibilityAdmission(input, sequence);
      setStatus(error?.message || t("status.localDraftStorageFailed"), true);
    });
}

function scheduleDirectBlockRecoveryAdmission(row, sequence) {
  const blockId = row?.dataset.blockId;
  const pageId = state.selectedPage?.id;
  if (!blockId || !pageId) return;
  const authenticationScope = captureAuthenticatedSessionScope();
  const navigationGeneration = workspaceNavigationGeneration;
  const editRevision = Number.parseInt(row.dataset.editRevision ?? "0", 10) || 0;
  const draftSourceId = row.dataset.draftSourceId || pageDraftSourceId;
  const payload = buildBlockPayload(row);
  // A rebuilt row starts a new visibility admission even when it has the same
  // block id and sequence. Never fall back to a detached row: restoring it can
  // rerender the selected page or cancel the replacement editor's autosave.
  const isCurrentAdmission = () => Boolean(
    isCurrentAuthenticatedSessionScope(authenticationScope)
      && isCurrentWorkspaceNavigation(navigationGeneration)
      && state.selectedPage?.id === pageId
      && !isCollaborativePage()
      && findRenderedBlockRow(blockId) === row
      && getBlockById(blockId)
      && row.dataset.deleting !== "true"
      && (Number.parseInt(row.dataset.editRevision ?? "0", 10) || 0) === editRevision
      && (row.dataset.draftSourceId || pageDraftSourceId) === draftSourceId
      && (Number.parseInt(row.dataset.recoveryAdmissionSequence ?? "0", 10) || 0) === sequence
      && jsonValuesMatch(buildBlockPayload(row), payload)
  );
  if (!isCurrentAdmission()) return;
  void requireDirectRecoveryDurability("direct-block-visible-admission", row, { preserveInput: false })
    .then(() => {
      if (!isCurrentAdmission()) return;
      finishDirectRecoveryVisibilityAdmission(row, sequence);
    })
    .catch(async (error) => {
      if (!isCurrentAdmission()) return;
      try { await recoveryStorage.refresh?.(); } catch { /* preserve the original failure */ }
      if (!isCurrentAdmission()) return;
      const restored = restoreBlockRowFromDurableState(row);
      if (restored) finishDirectRecoveryVisibilityAdmission(restored, sequence);
      setStatus(error?.message || t("status.localDraftStorageFailed"), true);
    });
}

'''
patched=old[:start]+new+old[end:]
# Preserve the uploaded app's CRLF convention and every byte outside this edit.
p.write_bytes(patched.replace('\n','\r\n').encode('utf-8') if b'\r\n' in raw else patched.encode('utf-8'))
print('Patched public/app.js; original lines:',len(old.splitlines()),'patched lines:',len(patched.splitlines()))
