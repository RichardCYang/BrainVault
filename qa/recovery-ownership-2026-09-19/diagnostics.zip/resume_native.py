from pathlib import Path
import subprocess, os, json, re, time, signal, concurrent.futures, sys
w=Path('/mnt/data/brainvault_workspace');d=Path('/mnt/data/maintenance_diagnostics')
statusdir=d/'native-status'; statusdir.mkdir(exist_ok=True)
files=[]
for p in sorted(w.glob('tests/*.node.test.mjs')):
 log=d/'native'/(p.stem+'.log')
 text=log.read_text(errors='replace') if log.exists() else ''
 if not re.search(r'^# duration_ms [\d.]+\s*$',text,re.M):files.append(p)
# Finish ordinary files first; isolate heavy resource benchmarks to avoid a
# slow subprocess masking completion of the rest of the checks.
files.sort(key=lambda p:('resource' in p.name,p.name))
limit=int(sys.argv[1]) if len(sys.argv)>1 else 20
files=files[:limit]
print('Running',len(files),'remaining files',flush=True)
def one(p):
 label='native/'+p.stem; log=d/(label+'.log'); command=['node','--experimental-strip-types','--test','--test-reporter=tap',str(p.relative_to(w))]
 start=time.monotonic()
 with log.open('w') as out:
  out.write('$ '+' '.join(command)+'\n');out.flush()
  proc=subprocess.Popen(command,cwd=w,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'),stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  try: code=proc.wait(timeout=20)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGKILL);proc.wait();code='timeout';out.write('\nTIMEOUT after 20 seconds\n')
 text=log.read_text(errors='replace');counts={k:int(v) for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)\s*$',text,re.M)}
 result={'label':label,'command':command,'exit_code':code,'seconds':round(time.monotonic()-start,3),'counts':counts,'log':str(log.relative_to(d))}
 (statusdir/(p.stem+'.json')).write_text(json.dumps(result,indent=2));return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
 for r in executor.map(one,files):print(r['label'],r['exit_code'],r['counts'],flush=True)
