from pathlib import Path, PurePosixPath
import zipfile, subprocess, os, json
archive = Path('/mnt/data/BrainVault.zip')
workspace = Path('/mnt/data/brainvault_workspace')
workspace.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
    for entry in z.infolist():
        path=PurePosixPath(entry.filename)
        if path.is_absolute() or '..' in path.parts or '\\' in entry.filename:
            raise ValueError(f'Unsafe archive path: {entry.filename}')
        mode=entry.external_attr >> 16
        if (mode & 0o170000) == 0o120000:
            raise ValueError(f'Symlink requires manual inspection: {entry.filename}')
subprocess.run(['unzip','-q',str(archive),'-d',str(workspace)],check=True)
# Hash via system utilities only; no Python reads of Git objects.
manifest=subprocess.run(['bash','-lc',"find .git -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum"],cwd=workspace,check=True,text=True,capture_output=True).stdout
Path('/mnt/data/maintenance_diagnostics/git-before.sha256').write_text(manifest)
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0')
base=['git','-c','safe.directory='+str(workspace),'-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null','-c','gc.auto=0','-c','maintenance.auto=false']
commands=[['status','--short'],['log','-18','--date=iso-strict','--format=%h %ad %s'],['show','--stat','--oneline','HEAD'],['ls-files','src','public','tests','scripts']]
with Path('/mnt/data/maintenance_diagnostics/git-initial.txt').open('w') as out:
    for args in commands:
        p=subprocess.run(base+args,cwd=workspace,env=env,text=True,capture_output=True)
        text='$ git '+' '.join(args)+'\n'+p.stdout+p.stderr+'\n'
        out.write(text)
        print(text if args[0]!='ls-files' else 'Tracked-file listing recorded in git-initial.txt')
for filename in ['package.json','tsconfig.json','README.md','.npmrc']:
    print('\n=== '+filename+' ===\n'+(workspace/filename).read_text()[:22000])
print('\n=== source tree ===')
print(subprocess.run(['find','src','public','-maxdepth','3','-type','f'],cwd=workspace,capture_output=True,text=True).stdout)
