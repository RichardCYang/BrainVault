from pathlib import Path
import subprocess, os, json, time, concurrent.futures, re
w=Path('/mnt/data/brainvault_workspace'); d=Path('/mnt/data/maintenance_diagnostics')
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0')
checks=[]
def run(label,command,timeout=90):
    start=time.monotonic()
    log=d/(label+'.log');log.parent.mkdir(exist_ok=True,parents=True)
    with log.open('w') as out:
        out.write('$ '+' '.join(command)+'\n');out.flush()
        try: p=subprocess.run(command,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=timeout); code=p.returncode
        except subprocess.TimeoutExpired: code='timeout'
    text=log.read_text(errors='replace')
    counts={k:int(v) for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)\s*$',text,re.M)}
    return {'label':label,'command':command,'exit_code':code,'seconds':round(time.monotonic()-start,3),'counts':counts,'log':str(log.relative_to(d))}
files=sorted(w.glob('tests/*.node.test.mjs'))
print('Native fallback files:',len(files),flush=True)
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    jobs={pool.submit(run,'native/'+p.stem,['node','--experimental-strip-types','--test','--test-reporter=tap',str(p.relative_to(w))],60):p for p in files}
    for future in concurrent.futures.as_completed(jobs):
        r=future.result();results.append(r)
        if r['exit_code']!=0: print('NATIVE FAILURE',r['label'],r['exit_code'],flush=True)
        if len(results)%50==0: print('Completed',len(results),'/',len(files),flush=True)
results.sort(key=lambda r:r['label'])
(d/'native-results.json').write_text(json.dumps(results,indent=2))
print('NATIVE SUMMARY',json.dumps({'files':len(results),'passing_files':sum(r['exit_code']==0 for r in results),'failed_files':sum(r['exit_code']!=0 for r in results),'totals':{k:sum(r['counts'].get(k,0) for r in results) for k in ['tests','pass','fail','cancelled','skipped']}}),flush=True)
