from pathlib import Path
p=Path('/mnt/data/brainvault_workspace/public/app.js')
s=p.read_bytes().decode().replace('\r\n','\n')
start=s.index('async function saveBlockRow(')
end=s.index('\nfunction scheduleBlockSave(',start)
block=s[start:end]
needle='''  assertCurrentAuthenticatedSessionScope(authenticationScope);
  const payload = buildBlockPayload(row);'''
replacement='''  assertCurrentAuthenticatedSessionScope(authenticationScope);
  // A delayed editor callback may still hold the row from before a locale,
  // reorder, or recovery rebuild. Reject obsolete input before it can replace
  // the durable draft or manufacture a revision equal to a newer saved edit.
  const renderedRow = findRenderedBlockRow(blockId);
  if (renderedRow && renderedRow !== row) {
    const sourceRevision = Number.parseInt(row.dataset.editRevision ?? "0", 10) || 0;
    const renderedRevision = Number.parseInt(renderedRow.dataset.editRevision ?? "0", 10) || 0;
    if (
      sourceRevision !== renderedRevision
      || (row.dataset.draftSourceId || pageDraftSourceId)
        !== (renderedRow.dataset.draftSourceId || pageDraftSourceId)
      || !jsonValuesMatch(buildBlockPayload(row), buildBlockPayload(renderedRow))
    ) {
      syncBeforeUnloadProtection();
      return null;
    }
    // Equivalent rebuilds remain saveable, but their current conflict/deletion
    // flags and recovery metadata, not those on the detached row, are binding.
    row = renderedRow;
  }
  if (row.dataset.deleting === "true") return null;
  const payload = buildBlockPayload(row);'''
assert block.count(needle)==1
block=block.replace(needle,replacement)
needle='''  if (admissionRevision !== editRevision) {
    syncBeforeUnloadProtection();
    return null;
  }
  recordBlockEditorHistory(row, payload);'''
replacement='''  if (
    admissionRevision !== editRevision
    || admissionRow.dataset.deleting === "true"
    || admissionRow.dataset.draftConflict === "true"
    || (admissionRow.dataset.draftSourceId || pageDraftSourceId) !== draftSourceId
    || !jsonValuesMatch(buildBlockPayload(admissionRow), payload)
  ) {
    // Revisions are local to a recovery source. A same-revision replacement
    // or a conflict raised by another save is not permission to overwrite it.
    syncBeforeUnloadProtection();
    return null;
  }
  row = admissionRow;
  recordBlockEditorHistory(row, payload);'''
assert block.count(needle)==1
block=block.replace(needle,replacement)
s=s[:start]+block+s[end:]
needle='''    pageTitleEditRevision !== editRevision
    || (pageTitleDraftSourceId || pageDraftSourceId) !== draftSourceId
  ) {'''
replacement='''    pageTitleEditRevision !== editRevision
    || (pageTitleDraftSourceId || pageDraftSourceId) !== draftSourceId
    || pageTitleDraftConflict
    || !elements.pageTitle.value.trim()
    || normalizePageTitle(elements.pageTitle.value) !== title
  ) {'''
assert s.count(needle)==1
s=s.replace(needle,replacement)
p.write_bytes(s.replace('\n','\r\n').encode())
print('Patched public/app.js, preserving the archive\'s CRLF line endings.')
