const fs = require('node:fs');
const path = require('node:path');
const ts = require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');
const root = process.argv[2];
const files=[];
function walk(dir) { for (const e of fs.readdirSync(dir,{withFileTypes:true})) {
  if (e.name.startsWith('.') || ['node_modules','dist','qa'].includes(e.name)) continue;
  const p=path.join(dir,e.name);
  if (e.isDirectory()) walk(p); else if (/\.(?:[cm]?js|tsx?)$/.test(e.name)) files.push(p);
}}
for(const name of ['public','src','tests','scripts']) walk(path.join(root,name));
const errors=[];
for(const file of files) {
  const kind=file.endsWith('.tsx')?ts.ScriptKind.TSX:/\.tsx?$/.test(file)?ts.ScriptKind.TS:ts.ScriptKind.JS;
  const source=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true,kind);
  for(const diagnostic of source.parseDiagnostics) {
    const lc=source.getLineAndCharacterOfPosition(diagnostic.start||0);
    errors.push({file:path.relative(root,file),line:lc.line+1,column:lc.character+1,message:ts.flattenDiagnosticMessageText(diagnostic.messageText,'\n')});
  }
}
console.log(JSON.stringify({typescript:ts.version,mode:'syntax-only; not dependency resolution or semantic type checking',files:files.length,errors},null,2));
process.exitCode=errors.length?1:0;
