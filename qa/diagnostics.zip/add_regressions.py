from pathlib import Path
root=Path('/mnt/data/brainvault_workspace')
p=root/'tests/save-admission-revision-race.node.test.mjs'
s=p.read_bytes().decode().replace('\r\n','\n')
s=s.replace('assert.equal(options.body.expectedVersion, serverPage.version, "page optimistic version");', '''if (options.body.expectedVersion !== serverPage.version) {
          throw Object.assign(new Error("Remote title changed"), { code: "PAGE_EDIT_CONFLICT" });
        }''')
s=s.replace('assert.equal(options.body.expectedVersion, serverBlock.version, "block optimistic version");', '''if (options.body.expectedVersion !== serverBlock.version) {
        throw Object.assign(new Error("Remote block changed"), { code: "BLOCK_EDIT_CONFLICT" });
      }''')
needle='    pauseNextSave() { const barrier = deferred(); nextDurabilityBarrier = barrier; return barrier; },'
assert s.count(needle)==1
s=s.replace(needle,needle+'''
    remoteEdit(kind, value) {
      if (kind === "title") {
        serverPage = { ...serverPage, title: value, version: serverPage.version + 1 };
      } else {
        serverBlock = { ...serverBlock, ...payload(value), version: serverBlock.version + 1 };
        serverPage.contentVersion += 1;
      }
    },
    refreshCanonicalVersion(kind) {
      if (kind === "title") context.state.selectedPage.version = serverPage.version;
      else context.state.selectedPage.blocks = [clone(serverBlock)];
    },''')
s+='''

// Delayed callbacks can hold an old DOM row before saveBlockRow even starts.
// A post-await revision check is too late: persistence itself can replace the
// newer recovery record, and a manufactured revision can alias a completed edit.
test("a detached callback cannot replace a newer durable draft before admission", async () => {
  const h = createHarness();
  h.editBlock("block A");
  const detachedRow = h.rebuildRow();
  h.editBlock("block B");
  const timer = h.context.blockSaveTimers.get("block-1");
  const before = JSON.stringify(h.blockDraft);
  assert.equal(await h.context.subject.saveBlockRow(detachedRow, { quiet: true }), null);
  assert.equal(JSON.stringify(h.blockDraft), before, "B must remain the crash-recovery copy");
  assert.equal(h.requests.length, 0);
  assert.ok(h.timers.has(timer));
});

test("a detached callback cannot overwrite a newer completed block save", async () => {
  const h = createHarness();
  h.editBlock("block A");
  const detachedRow = h.rebuildRow();
  h.editBlock("block B");
  await h.saveBlock();
  assert.equal(h.serverMarkdown, "block B");
  assert.equal(h.blockDraft, undefined);
  await h.context.subject.saveBlockRow(detachedRow, { quiet: true });
  assert.equal(h.serverMarkdown, "block B", "an old DOM row must not manufacture B's revision");
  assert.equal(h.blockDraft, undefined);
  assert.equal(h.requests.length, 1);
});

test("an equivalent rebuilt row can still be saved by its pending callback", async () => {
  const h = createHarness();
  h.editBlock("unchanged rebuild");
  const detachedRow = h.rebuildRow();
  await h.context.subject.saveBlockRow(detachedRow, { quiet: true });
  assert.equal(h.serverMarkdown, "unchanged rebuild");
  assert.equal(h.blockDraft, undefined);
  assert.equal(h.requests.length, 1);
});

for (const kind of ["title", "block"]) {
  test(`a paused ${kind} save cannot bypass a conflict raised by another save`, async () => {
    const h = createHarness();
    const save = () => kind === "title" ? h.saveTitle() : h.saveBlock();
    if (kind === "title") h.editTitle("local draft");
    else h.editBlock("local draft");
    const barrier = h.pauseNextSave();
    const delayedSave = save();
    h.remoteEdit(kind, "new remote content");
    await assert.rejects(save(), { code: kind === "title" ? "PAGE_EDIT_CONFLICT" : "BLOCK_EDIT_CONFLICT" });
    // A canonical summary/row refresh must not count as overwrite consent.
    h.refreshCanonicalVersion(kind);
    const requestCount = h.requests.length;
    const draft = kind === "title" ? h.titleDraft : h.blockDraft;
    barrier.resolve();
    assert.equal(await delayedSave, null);
    assert.equal(h.requests.length, requestCount, "the rejected draft must not be silently re-admitted");
    assert.equal(kind === "title" ? h.serverTitle : h.serverMarkdown, "new remote content");
    assert.deepEqual(kind === "title" ? h.titleDraft : h.blockDraft, draft);
    assert.equal(kind === "title" ? h.context.pageTitleDraftConflict : h.row.dataset.draftConflict === "true", true);
  });
}

test("same-revision block payload replacement during durability is not stale-save consent", async () => {
  const h = createHarness();
  h.editBlock("old local payload");
  const barrier = h.pauseNextSave();
  const delayedSave = h.saveBlock();
  h.rebuildRow();
  h.row.payload.markdown = "replacement recovery payload";
  h.context.subject.persistBlockDraft(h.row);
  barrier.resolve();
  assert.equal(await delayedSave, null);
  assert.equal(h.requests.length, 0);
  assert.equal(h.blockDraft.payload.markdown, "replacement recovery payload");
});

test("same-revision block recovery-source replacement cannot authorize the old source", async () => {
  const h = createHarness();
  h.editBlock("old source payload");
  const barrier = h.pauseNextSave();
  const delayedSave = h.saveBlock();
  h.row.dataset.draftSourceId = "replacement-source";
  h.context.subject.persistBlockDraft(h.row);
  barrier.resolve();
  assert.equal(await delayedSave, null);
  assert.equal(h.requests.length, 0);
  assert.equal(h.blockDraft.payload.markdown, "old source payload");
  assert.ok(h.store.loadPage("user-1", "page-1", "replacement-source")?.blocks?.["block-1"]);
});
'''
p.write_bytes(s.replace('\n','\r\n').encode())
print('Added 7 deterministic regression tests and remote-write behavior to the production-function harness.')
