"""Run each existing Node suite in isolation; keep complete logs and per-suite outcomes."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import subprocess, os, time, signal, json, re
root=Path('/mnt/data/brainvault_workspace'); out=Path('/mnt/data/brainvault_qa'); logs=out/'node-suite-logs';logs.mkdir(exist_ok=True)
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_COUNT':'4','GIT_CONFIG_KEY_0':'safe.directory','GIT_CONFIG_VALUE_0':str(root),'GIT_CONFIG_KEY_1':'core.fsmonitor','GIT_CONFIG_VALUE_1':'false','GIT_CONFIG_KEY_2':'core.untrackedCache','GIT_CONFIG_VALUE_2':'false','GIT_CONFIG_KEY_3':'core.hooksPath','GIT_CONFIG_VALUE_3':'/dev/null'}
def run(p):
    target=logs/(p.name+'.tap'); cmd=['node','--experimental-strip-types','--test','--test-reporter=tap',str(p.relative_to(root))]; started=time.monotonic(); timed_out=False
    with target.open('w') as f:
        proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        try: rc=proc.wait(timeout=13)
        except subprocess.TimeoutExpired:
            timed_out=True;os.killpg(proc.pid,signal.SIGKILL);rc=proc.wait()
    text=target.read_text();counts={key:int(m.group(1)) if (m:=re.search(r'^# '+key+r' (\d+)$',text,re.M)) else None for key in ['tests','pass','fail','cancelled','skipped']}
    fails=re.findall(r'^not ok \d+ - (.*)$',text,re.M)
    errors=sorted(set(re.findall(r"(?:Cannot find (?:package|module) '[^']+'|ERR_MODULE_NOT_FOUND|ERR_ASSERTION)",text)))
    return {'file':str(p.relative_to(root)),'exit_code':rc,'timed_out':timed_out,'seconds':round(time.monotonic()-started,3),'counts':counts,'failed_tests':fails,'errors':errors,'command':cmd}
results=[]; start=time.monotonic()
with ThreadPoolExecutor(max_workers=10) as pool:
    for future in as_completed([pool.submit(run,p) for p in sorted((root/'tests').glob('*.node.test.mjs'))]): results.append(future.result())
results.sort(key=lambda x:x['file']);(out/'node-suite-results.json').write_text(json.dumps(results,indent=2))
summary={'suites':len(results),'passed_suites':sum(r['exit_code']==0 for r in results),'failed_suites':sum(r['exit_code']!=0 for r in results),'timeouts':sum(r['timed_out'] for r in results),'reported_counts':{k:sum(r['counts'][k] or 0 for r in results) for k in ['tests','pass','fail','cancelled','skipped']},'seconds':round(time.monotonic()-start,2)}
(out/'node-suite-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
for r in results:
    if r['exit_code']!=0: print('NONPASS',r['file'],'timeout='+str(r['timed_out']),r['failed_tests'],r['errors'])
